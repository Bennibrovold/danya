import React from "react";

export function Contact() {
  return <div>Contact</div>;
}
