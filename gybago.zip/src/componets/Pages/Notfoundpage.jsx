import React from "react";

export function Notfoundpage() {
  return <div>Notfoundpage</div>;
}
