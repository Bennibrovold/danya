import React from "react";

export function Soon() {
  return <div>Soon</div>;
}
