import React from "react";

export function Сatalog() {
  return <div>Сatalog</div>;
}
