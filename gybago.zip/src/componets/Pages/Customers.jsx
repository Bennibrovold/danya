import React from "react";

export function Customers() {
  return <div>Customers</div>;
}
