import logo from "./logo.svg";
import "./App.css";
import Chelka from "./componets/main";
import Footer from "./componets/Footer/Footer";

function App() {
  return (
    <>
      <Chelka />
      <Footer />
    </>
  );
}

export default App;
